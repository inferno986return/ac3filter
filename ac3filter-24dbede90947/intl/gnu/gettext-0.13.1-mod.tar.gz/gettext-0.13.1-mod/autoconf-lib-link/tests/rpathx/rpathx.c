int rpathx_value () { return 5; }
